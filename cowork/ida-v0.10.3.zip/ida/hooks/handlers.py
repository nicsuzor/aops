from __future__ import annotations

"""ida hook handlers."""


import logging
import os
import re
import shlex
import shutil
import socket
import subprocess
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

from dispatch import HookContext, Result, load_message_pair, warn

Handler = Callable[[HookContext], Result | None]

log = logging.getLogger("aops.handlers")

try:
    import claude_code_tracer
except ImportError as exc:
    claude_code_tracer = None
    log.warning(
        "claude_code_tracer did not import (%s) — OTel tracing is disabled for every hook",
        exc,
    )

try:
    import agy_tracer
except ImportError as exc:
    agy_tracer = None
    log.warning("agy_tracer did not import (%s)", exc)

_BASIC_VARS = (
    "AOPS_SESSIONS",
    "AOPS_BOT_GH_TOKEN",
    "PKB_MCP_URL",
    "PKB_MCP_TOOL_PREFIX",
)


# Measured 2026-09-12 (scripts/measure_pkb_injection.py, n=30 live fires
# across two prompt families): backend search latency p95 ~1.35s, median
# ~1.29s. 5s clears that with >3x margin while cutting the worst-case block
# on a stalled backend from 15s to 5s -- this hook is synchronous ahead of
# every prompt, so a hang here is a hang for the whole turn.
_SEARCH_TIMEOUT_SECONDS = 5

# Same measurement run: payload size for 5 results was 3.5-6.4KB (p95). This
# hook fires on every single UserPromptSubmit -- the highest-frequency
# injection point in the framework -- and had no ceiling of its own,
# inheriting whatever the `pkb` CLI's default result count/format produced.
# Set well above the measured p95 so normal output is never touched; it only
# bites if the backend's output grows unexpectedly large.
_MAX_INJECT_CHARS = 8000
_TRUNCATION_MARKER = "\n[...truncated, output exceeded injection budget...]"


def honest_output(ctx: HookContext) -> Result | None:
    """Remind agents to present substantiating evidence with their claims."""
    if ctx.agent_type and ctx.agent_type.endswith((":ida", ":james")):
        return None

    if ctx.raw.get("background_tasks"):
        return None

    return warn(*load_message_pair(ctx.hooks_dir, "honesty"))


def _find_pkb_bin(cwd: str | Path | None = None) -> str | None:
    pkb_bin = shutil.which("pkb")
    if pkb_bin:
        return pkb_bin
    candidates: list[Path] = []
    if cwd:
        candidates.append(Path(cwd) / "pkb")
    candidates.append(Path.cwd() / "pkb")
    for candidate in candidates:
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate.resolve())

    return None


def _cap_output(out: str) -> str:
    """Bound injected payload size, independent of what the backend returns.

    A per-turn hook has no natural upper limit from its caller -- the CLI's
    own result count and formatting decide payload size today. This is the
    hook's own ceiling, not a substitute for the backend returning a
    reasonable number of results.
    """
    if len(out) <= _MAX_INJECT_CHARS:
        return out
    cutoff = _MAX_INJECT_CHARS - len(_TRUNCATION_MARKER)
    return out[:cutoff].rstrip() + _TRUNCATION_MARKER


def _run_pkb_search(prompt: str, cwd: str | Path | None = None) -> str | None:
    query = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", prompt).strip()[:200]
    if not query:
        return None
    pkb_bin = _find_pkb_bin(cwd)
    if not pkb_bin:
        log.warning("pkb binary not found for UserPromptSubmit hook")
        return None
    try:
        env = dict(os.environ)
        env["NO_COLOR"] = "1"
        proc = subprocess.run(
            [pkb_bin, "search", query],
            capture_output=True,
            text=True,
            timeout=_SEARCH_TIMEOUT_SECONDS,
            cwd=str(cwd) if cwd and Path(cwd).is_dir() else None,
            env=env,
        )
        if proc.returncode == 0:
            out = proc.stdout.strip()
            out = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", out).strip()
            if out:
                return _cap_output(out)
        else:
            log.warning("pkb search exited with returncode %s: %s", proc.returncode, proc.stderr)
    except Exception as exc:
        log.warning("pkb search execution failed: %s", exc)
    return None


def search_the_pkb(ctx: HookContext) -> Result | None:
    """Ground every prompt in the PKB before the agent acts on it.

    Tries first to return the output of `pkb search {prompt:200}` wrapped in
    `<academicOps PKB search results>` tags; if that fails, returns the
    existing messages.
    """
    if ctx.agent_type and ctx.agent_type.endswith(":ida"):
        return None

    raw_prompt = ctx.raw.get("prompt")
    if raw_prompt is None and hasattr(ctx, "prompt"):
        raw_prompt = ctx.prompt
    if isinstance(raw_prompt, dict):
        raw_prompt = raw_prompt.get("text") or raw_prompt.get("content") or ""
    prompt_str = str(raw_prompt or "").strip()

    if prompt_str:
        output = _run_pkb_search(prompt_str, cwd=ctx.cwd)
        if output:
            msg = f"<academicOps PKB search results>\n{output}\n</academicOps PKB search results>"
            return warn(msg)

    return honest_output(ctx)


def be_quiet(ctx: HookContext) -> Result | None:
    """Remind the face to strip its reply down to what is load-bearing."""
    # Only fire on Ida
    if ctx.agent_type == "ida:ida":
        if ctx.raw.get("background_tasks"):
            return None
        return warn(*load_message_pair(ctx.hooks_dir, "quiet"))

    return None


def _scrub(value: object) -> str:
    """Neutralise characters that let a client-supplied value forge a field."""
    return " ".join(str(value).split()).replace("|", "")


def _format_session_metadata(ctx: HookContext) -> str:
    now = datetime.now().astimezone()
    time_str = now.strftime("%Y-%m-%d %H:%M:%S %z")

    try:
        hostname = socket.gethostname()
    except Exception:
        hostname = ""

    session_id = ctx.session_id or ctx.raw.get("session_id") or ctx.raw.get("conversationId") or ""
    cwd = ctx.cwd or ctx.raw.get("cwd") or ""

    pkb_version = os.environ.get("PKB_VERSION") or ctx.raw.get("pkb_version") or "unknown"

    parts = [
        f"session: {_scrub(session_id)}" if session_id else "session: unknown",
        f"time: {time_str}",
        f"host: {_scrub(hostname)}" if hostname else "host: unknown",
        f"cwd: {_scrub(cwd)}" if cwd else "cwd: unknown",
    ]
    parts.append(f"pkb: {_scrub(pkb_version)}")

    plugin_ver = (
        os.environ.get("AOPS_IMAGE_PLUGINS_VERSION")
        or ctx.raw.get("plugins")
        or ctx.raw.get("plugins_version")
    )
    if plugin_ver:
        parts.append(f"plugins: {_scrub(str(plugin_ver))}")

    otel_endpoint = (
        os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
        or os.environ.get("BETA_TRACING_ENDPOINT")
        or os.environ.get("GENAI_ENGINE_TRACE_ENDPOINT")
    )
    if otel_endpoint:
        service_name = os.environ.get("OTEL_SERVICE_NAME") or "unknown"
        parts.append(f"tracing: {_scrub(otel_endpoint)} (service: {_scrub(service_name)})")
    else:
        parts.append("tracing: unconfigured")

    return " | ".join(parts)


def _get_injected_files(ctx: HookContext) -> list[str]:
    injected_str = os.environ.get("AOPS_INJECT_FILES", "").strip()
    if not injected_str:
        return []

    lines = []
    base_dir = ctx.cwd
    for p_str in injected_str.split(","):
        p_str = p_str.strip()
        if not p_str:
            continue
        p = Path(p_str)
        if not p.is_absolute():
            p = base_dir / p

        if p.exists() and p.is_file():
            try:
                content = p.read_text(encoding="utf-8")
                lines.append(f"--- START: {p_str} ---\n{content}\n--- END: {p_str} ---")
            except Exception as e:
                lines.append(f"--- ERROR reading {p_str}: {e} ---")
        else:
            lines.append(f"--- MISSING: {p_str} ---")
    return lines


def _read_env_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if not path.exists():
        return out
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export ") :].lstrip()
        k, sep, v = line.partition("=")
        if not sep:
            continue
        k = k.strip()
        v = v.strip()
        if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
            v = v[1:-1]
        out[k] = v
    return out


def _write_env_file(path: Path, values: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [f"export {k}={shlex.quote(v)}" for k, v in sorted(values.items())]
    content = "\n".join(lines) + ("\n" if lines else "")
    path.write_text(content, encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def _isolate_credentials(ctx: HookContext) -> bool:
    env_file_str = os.environ.get("CLAUDE_ENV_FILE")
    if not env_file_str:
        return False
    env_file = Path(env_file_str)

    existing = _read_env_file(env_file)
    moved: dict[str, str] = {}

    for var in _BASIC_VARS:
        val = os.environ.get(var)
        if val is not None:
            moved[var] = val

    if not moved:
        return False

    existing.update(moved)
    _write_env_file(env_file, existing)

    for var in moved:
        os.environ.pop(var, None)

    return True


def session_start(ctx: HookContext) -> Result | None:
    """Handle SessionStart for Claude Code and SessionStart for agy."""
    metadata = _format_session_metadata(ctx)
    parts = ["aops hook: Session started.", metadata]
    user_parts = [metadata]
    stale_warning = os.environ.get("AOPS_IMAGE_STALENESS_WARNING") or ctx.raw.get(
        "image_staleness_warning"
    )
    if not stale_warning and (
        os.environ.get("AOPS_IMAGE_STALE") == "1" or ctx.raw.get("image_stale")
    ):
        stale_warning = (
            "[SYSTEM WARNING: RUNNING WITH STALE BAKED PLUGINS]\n"
            "Container plugin payload lags workspace under test.\n"
            "Any skill, hook, or MCP behavior verified in this session reflects the BAKED payload, NOT workspace edits."
        )

    if stale_warning:
        parts.append(stale_warning)
        user_parts.append(stale_warning)

    if _isolate_credentials(ctx):
        parts.append("Credentials have been isolated in CLAUDE_ENV_FILE.")
        user_parts.insert(0, "Credentials isolated.")

    injected = _get_injected_files(ctx)
    if injected:
        files_str = "Injected context files:\n" + "\n".join(injected)
        parts.append(files_str)
        user_parts.append(files_str)

    return warn("\n\n".join(parts), "\n\n".join(user_parts))


def rule_against_hearsay(ctx: HookContext) -> Result | None:
    """Remind the dispatcher that a subagent's report is not evidence."""
    # Only fire on supervisor profiles
    if ctx.agent_type in ("ida:ida", "aops:james"):
        if any(call.get("tool_name") == "Agent" for call in ctx.tool_calls):
            return warn(*load_message_pair(ctx.hooks_dir, "hearsay"))

    return None


def _prepare_tracer_data(ctx: HookContext) -> dict[str, Any]:
    """Extract and normalize payload dictionary for claude_code_tracer."""
    data = dict(ctx.raw)
    if ctx.session_id:
        data.setdefault("session_id", ctx.session_id)
    if ctx.cwd:
        data.setdefault("cwd", ctx.cwd)
    if ctx.agent_type:
        data.setdefault("agent_type", ctx.agent_type)
    if ctx.agent_id:
        data.setdefault("agent_id", ctx.agent_id)
    if ctx.tool:
        data.setdefault("tool_name", ctx.tool)
    if "toolName" in data and "tool_name" not in data:
        data["tool_name"] = data["toolName"]
    if "toolInput" in data and "tool_input" not in data:
        data["tool_input"] = data["toolInput"]
    if "toolResponse" in data and "tool_response" not in data:
        data["tool_response"] = data["toolResponse"]
    return data


def user_prompt_submit(ctx: HookContext) -> Result | None:
    """Tracer hook handler for canonical UserPromptSubmit, Claude Code side."""
    if claude_code_tracer is None or ctx.client != "claude":
        return None
    try:
        data = _prepare_tracer_data(ctx)
        config = claude_code_tracer.discover_config(data)
        if config is not None:
            claude_code_tracer.handle_user_prompt_submit(data, config)
    except Exception as exc:
        log.warning("claude_code_tracer user_prompt_submit failed: %s", exc)
    return None


def pre_tool(ctx: HookContext) -> Result | None:
    if claude_code_tracer is None or ctx.client != "claude":
        return None
    try:
        data = _prepare_tracer_data(ctx)
        config = claude_code_tracer.discover_config(data)
        if config is not None:
            claude_code_tracer.handle_pre_tool(data, config)
    except Exception as exc:
        log.warning("claude_code_tracer pre_tool failed: %s", exc)
    return None


def post_tool(ctx: HookContext) -> Result | None:
    if claude_code_tracer is None or ctx.client != "claude":
        return None
    try:
        data = _prepare_tracer_data(ctx)
        config = claude_code_tracer.discover_config(data)
        if config is not None:
            claude_code_tracer.handle_post_tool(data, config)
    except Exception as exc:
        log.warning("claude_code_tracer post_tool failed: %s", exc)
    return None


def post_tool_failure(ctx: HookContext) -> Result | None:
    if claude_code_tracer is None or ctx.client != "claude":
        return None
    try:
        data = _prepare_tracer_data(ctx)
        config = claude_code_tracer.discover_config(data)
        if config is not None:
            claude_code_tracer.handle_post_tool_failure(data, config)
    except Exception as exc:
        log.warning("claude_code_tracer post_tool_failure failed: %s", exc)
    return None


def stop(ctx: HookContext) -> Result | None:
    if claude_code_tracer is None or ctx.client != "claude":
        return None
    try:
        data = _prepare_tracer_data(ctx)
        config = claude_code_tracer.discover_config(data)
        if config is not None:
            claude_code_tracer.handle_stop(data, config)
    except Exception as exc:
        log.warning("claude_code_tracer stop failed: %s", exc)
    return None


def agy_user_prompt_submit(ctx: HookContext) -> Result | None:
    if agy_tracer is None or ctx.client != "agy":
        return None
    try:
        config = agy_tracer.discover_config()
        if config is not None:
            data = _prepare_tracer_data(ctx)
            agy_tracer.handle_pre_invocation(data, config)
    except Exception as exc:
        log.warning("agy_user_prompt_submit tracer failed: %s", exc)
    return None


def agy_pre_tool(ctx: HookContext) -> Result | None:
    if agy_tracer is None or ctx.client != "agy":
        return None
    try:
        config = agy_tracer.discover_config()
        if config is not None:
            data = _prepare_tracer_data(ctx)
            agy_tracer.handle_pre_tool(data, config)
    except Exception as exc:
        log.warning("agy_pre_tool tracer failed: %s", exc)
    return None


def agy_post_tool(ctx: HookContext) -> Result | None:
    if agy_tracer is None or ctx.client != "agy":
        return None
    try:
        config = agy_tracer.discover_config()
        if config is not None:
            data = _prepare_tracer_data(ctx)
            agy_tracer.handle_post_tool(data, config)
    except Exception as exc:
        log.warning("agy_post_tool tracer failed: %s", exc)
    return None


def agy_stop(ctx: HookContext) -> Result | None:
    if agy_tracer is None or ctx.client != "agy":
        return None
    try:
        config = agy_tracer.discover_config()
        if config is not None:
            data = _prepare_tracer_data(ctx)
            agy_tracer.handle_stop(data, config)
    except Exception as exc:
        log.warning("agy_stop tracer failed: %s", exc)
    return None


HANDLERS: dict[str, list] = {
    "SessionStart": [session_start],
    "UserPromptSubmit": [user_prompt_submit, agy_user_prompt_submit, search_the_pkb],
    "PreToolUse": [h for h in (pre_tool, agy_pre_tool) if h is not None],
    "PostToolUse": [post_tool, agy_post_tool],
    "PostToolUseFailure": [post_tool_failure],
    "Stop": [stop, agy_stop],
    #   "PostToolBatch": [rule_against_hearsay,be_quiet],
    # "SubagentStart": [honest_output],
}
