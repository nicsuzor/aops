---
title: Code task base
type: template
description: Alternative foundation for code-change tasks executed via /ida:pull -- test-first build, push and PR, then a fresh worker's strategic review ending in a verdict on the PR.
tags: [base, task, code, composite]
---

- **GOAL:** <one sentence>
- **ACCEPTANCE CRITERIA:** <one line each>
  - <criterion>
  - <criterion>
- [ ] **OUTPUT:** <repository and base branch the PR targets>
- **REPORT:** Use /ida:dump to update your task. Do not append your observations as a log; update the prose to reflect current state and delete any content that is no longer relevant, true, or that reflects prior state or prior instructions. Update the ACCEPTANCE CRITERIA block to check off each item and, on the same line, provide a relevant extract of your evidence supporting your assertion that the criterion is complete/incomplete, along with a citation for the source of the evidence.

## Stages

1. **Build test-first** -- a red-green-refactor implementation of the acceptance criteria: each behaviour's failing test captured before its code, full suite green at the end.
2. **Push and file the PR** -- push the branch and open a pull request against the base branch, its description mapping each acceptance criterion to the tests and commits that meet it. Record the PR URL on the task and release it as `done`.
3. **Review and verdict** -- in a separate task, by a fresh worker that did not write the code. Run `/strategic-review` on the PR, push fixes for defects small enough to settle in place, and post the review to the PR on GitHub. Then reach exactly one verdict:
   - **Rejected** -- the approach is wrong or the PR cannot be salvaged: close the PR with the review as the closing comment, and set the implementation task to `cancelled` with the reason.
   - **Extensive revisions** -- the PR is sound in direction but needs more than in-place fixes: file a fix follow-up task that names each required change and `depends_on` the review task, leave the PR open, and link the follow-up from the review.
   - **Mergeable** -- the review is clean, checks are green, and GitHub reports the PR mergeable: post a merge recommendation on the PR citing the green checks and the review, and release the review task as `merge_ready`. Do not merge.

## Composition

Cut the chain after stage 2: stages 1--2 form one task; stage 3 is a second task that `depends_on` the first, so a fresh worker picks it up with no shared context.

## Output contract

- Stage 1--2 task: tests with their red failure traces, a green full-suite run, and the open PR with its URL on the task record.
- Stage 3 task: the review posted on the PR, any in-place fix commits, and one verdict carried out -- PR closed and implementation task `cancelled`, a fix follow-up task filed, or a merge recommendation posted with the review task released as `merge_ready`.

## When to include

Any task whose deliverable is a code change to a repository. Use in place of the general task base when the work should arrive as a reviewed PR rather than a finished artifact.
